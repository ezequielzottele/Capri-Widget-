package com.capricompanion

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(android.graphics.Color.rgb(17, 16, 27))
        }
        fun label(text: String, size: Float, color: Int) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color); setPadding(0, 12, 0, 12)
        }
        root.addView(label("CAPRI COMPANION", 27f, android.graphics.Color.WHITE))
        root.addView(label("Seu painel pessoal", 15f, android.graphics.Color.rgb(67, 224, 208)))
        root.addView(label("Adicione os widgets à tela inicial: toque e segure um espaço vazio da tela, abra Widgets e procure CAPRI Companion.", 16f, android.graphics.Color.LTGRAY))
        root.addView(label("MÚSICA", 18f, android.graphics.Color.rgb(67, 224, 208)))
        root.addView(label("A versão inicial prepara o widget visual. A integração de reprodução com Spotify, outros players e biblioteca local requer permissões e implementação adicional de sessões de mídia.", 14f, android.graphics.Color.LTGRAY))
        setContentView(root)
    }
}
