package com.capricompanion

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.Locale

class ClockCalendarWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { render(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        when (intent.action) {
            ACTION_MONTH -> {
                val offset = intent.getIntExtra(EXTRA_OFFSET, 0)
                val current = prefs.getInt(KEY_MONTH_OFFSET, 0)
                prefs.edit().putInt(KEY_MONTH_OFFSET, current + offset).apply()
            }
            ACTION_DAY -> {
                val key = intent.getStringExtra(EXTRA_DAY) ?: return
                val marked = prefs.getStringSet(KEY_MARKED, emptySet())?.toMutableSet() ?: mutableSetOf()
                if (!marked.add(key)) marked.remove(key)
                prefs.edit().putStringSet(KEY_MARKED, marked).apply()
            }
        }
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, ClockCalendarWidget::class.java))
        ids.forEach { render(context, manager, it) }
    }

    private fun render(context: Context, manager: AppWidgetManager, appWidgetId: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val offset = prefs.getInt(KEY_MONTH_OFFSET, 0)
        val month = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); add(Calendar.MONTH, offset) }
        val year = month.get(Calendar.YEAR)
        val monthIndex = month.get(Calendar.MONTH)
        val locale = Locale("pt", "BR")
        val monthName = DateFormatSymbols(locale).months[monthIndex].uppercase(locale)
        val marked = prefs.getStringSet(KEY_MARKED, emptySet()) ?: emptySet()
        val today = Calendar.getInstance()
        val selectedDay = if (offset == 0) today.get(Calendar.DAY_OF_MONTH) else -1
        val views = RemoteViews(context.packageName, R.layout.widget_clock_calendar)
        views.setTextViewText(R.id.month, "$monthName $year")
        views.setTextViewText(R.id.marked, if (marked.isEmpty()) "NENHUM DIA MARCADO" else "${marked.size} DIA(S) MARCADO(S)  •  TOQUE PARA ALTERAR")
        views.setOnClickPendingIntent(R.id.previous, monthIntent(context, -1, appWidgetId))
        views.setOnClickPendingIntent(R.id.next, monthIntent(context, 1, appWidgetId))

        val firstDay = (month.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Monday = 0
        val maxDay = month.getActualMaximum(Calendar.DAY_OF_MONTH)
        for (cell in 0 until 42) {
            val viewId = dayViewId(cell)
            val day = cell - firstDay + 1
            if (day in 1..maxDay) {
                val key = String.format(Locale.US, "%04d-%02d-%02d", year, monthIndex + 1, day)
                views.setTextViewText(viewId, day.toString())
                val bg = when {
                    key in marked -> R.drawable.day_marked
                    day == selectedDay -> R.drawable.day_selected
                    else -> R.drawable.day_cell
                }
                views.setInt(viewId, "setBackgroundResource", bg)
                views.setTextColor(viewId, if (key in marked) 0xFF66E0D3.toInt() else 0xFFF7F2F8.toInt())
                views.setOnClickPendingIntent(viewId, dayIntent(context, key, appWidgetId * 100 + cell))
            } else {
                views.setTextViewText(viewId, "")
                views.setOnClickPendingIntent(viewId, null)
                views.setInt(viewId, "setBackgroundResource", R.drawable.day_cell)
            }
        }
        manager.updateAppWidget(appWidgetId, views)
    }

    private fun monthIntent(context: Context, offset: Int, request: Int): PendingIntent {
        val intent = Intent(context, ClockCalendarWidget::class.java).setAction(ACTION_MONTH).putExtra(EXTRA_OFFSET, offset)
        return PendingIntent.getBroadcast(context, 1000 + request + offset, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun dayIntent(context: Context, key: String, request: Int): PendingIntent {
        val intent = Intent(context, ClockCalendarWidget::class.java).setAction(ACTION_DAY).putExtra(EXTRA_DAY, key)
        return PendingIntent.getBroadcast(context, 5000 + request, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun dayViewId(index: Int): Int = when (index) {
        0 -> R.id.day_0
        1 -> R.id.day_1
        2 -> R.id.day_2
        3 -> R.id.day_3
        4 -> R.id.day_4
        5 -> R.id.day_5
        6 -> R.id.day_6
        7 -> R.id.day_7
        8 -> R.id.day_8
        9 -> R.id.day_9
        10 -> R.id.day_10
        11 -> R.id.day_11
        12 -> R.id.day_12
        13 -> R.id.day_13
        14 -> R.id.day_14
        15 -> R.id.day_15
        16 -> R.id.day_16
        17 -> R.id.day_17
        18 -> R.id.day_18
        19 -> R.id.day_19
        20 -> R.id.day_20
        21 -> R.id.day_21
        22 -> R.id.day_22
        23 -> R.id.day_23
        24 -> R.id.day_24
        25 -> R.id.day_25
        26 -> R.id.day_26
        27 -> R.id.day_27
        28 -> R.id.day_28
        29 -> R.id.day_29
        30 -> R.id.day_30
        31 -> R.id.day_31
        32 -> R.id.day_32
        33 -> R.id.day_33
        34 -> R.id.day_34
        35 -> R.id.day_35
        36 -> R.id.day_36
        37 -> R.id.day_37
        38 -> R.id.day_38
        39 -> R.id.day_39
        40 -> R.id.day_40
        41 -> R.id.day_41
        else -> R.id.day_0
    }

    companion object {
        private const val PREFS = "capri_calendar"
        private const val KEY_MONTH_OFFSET = "month_offset"
        private const val KEY_MARKED = "marked_days"
        private const val ACTION_MONTH = "com.capricompanion.CALENDAR_MONTH"
        private const val ACTION_DAY = "com.capricompanion.CALENDAR_DAY"
        private const val EXTRA_OFFSET = "offset"
        private const val EXTRA_DAY = "day"
    }
}
