# CAPRI Companion — widget de calendário Android

Esta entrega implementa o widget de calendário inspirado na referência enviada: painel escuro translúcido, detalhes roxo/rosa e ciano, navegação entre meses e marcação de dias.

## Funções implementadas
- Grade mensal de segunda a domingo, em português (Brasil).
- Navegação para mês anterior e próximo.
- Toque em um dia para marcar/desmarcar; as marcações ficam salvas no aparelho.
- Destaque visual para o dia atual e para dias marcados.
- Contador de dias marcados.

## Abrir e compilar
1. Abra esta pasta no Android Studio (versão recente).
2. Aguarde a sincronização do Gradle.
3. Conecte o Samsung com depuração USB ou use um emulador e pressione Run.
4. Para gerar APK: Build > Build APK(s).
5. Na tela inicial: toque e segure > Widgets > CAPRI Companion > Calendário.

## Nota
O ambiente de preparação não possui Android SDK/Gradle configurados, então não foi possível compilar ou testar um APK aqui. O código-fonte do widget está incluído para compilação no Android Studio.
